﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static SQLiteConnection CreateConnection()
        {

            SQLiteConnection sqlite_conn;
            // Create a new database connection:
            sqlite_conn = new SQLiteConnection("Data Source=database.db; Version = 3; New = True; Compress = True; ");
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception ex)
            {

            }
            return sqlite_conn;
        }

        static void CreateTable(SQLiteConnection conn)
        {

            SQLiteCommand sqlite_cmd;
            string Createsql = "CREATE TABLE CryptoData (Col1 INT, Col2 VARCHAR(1000))";
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = Createsql;
            sqlite_cmd.ExecuteNonQuery();
        }

        static void SetData(SQLiteConnection conn, string source)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM CryptoData WHERE Col1=1";

            SQLiteDataReader sqlite_datareader = sqlite_cmd.ExecuteReader();
            if (sqlite_datareader.Read())
            {
                sqlite_datareader.Close();
                sqlite_cmd.CommandText = $"UPDATE CryptoData SET Col2= '{source}' WHERE Col1=1; ";
            }
            else
            {
                sqlite_datareader.Close();
                sqlite_cmd.CommandText = $"INSERT INTO CryptoData (Col1, Col2) VALUES(1, '{source}'); ";
            }
            
            sqlite_cmd.ExecuteNonQuery();
            conn.Close();

        }

        static string ReadData(SQLiteConnection conn)
        {
            string res = null;
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT Col2 FROM CryptoData WHERE Col1=1";
            sqlite_datareader = sqlite_cmd.ExecuteReader();
            if (sqlite_datareader.Read())
            {
                res = sqlite_datareader.GetString(0);
            }
            conn.Close();
            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SQLiteConnection sqlite_conn;
            sqlite_conn = CreateConnection();
            CreateTable(sqlite_conn);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SQLiteConnection sqlite_conn;
            sqlite_conn = CreateConnection();
            SetData(sqlite_conn, AESEncryption.Encrypt(AESEncryption.Encrypt(textBox2.Text, textBox1.Text), textBox1.Text)); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SQLiteConnection sqlite_conn;
            sqlite_conn = CreateConnection();
            string s = ReadData(sqlite_conn);
            textBox4.Text = s;
            textBox3.Text = AESEncryption.Decrypt(AESEncryption.Decrypt(s, textBox1.Text), textBox1.Text); 
        }
    }
}
